package dev.luminous.asm.mixins;

import dev.luminous.api.utils.render.ModelPlayer;
import dev.luminous.mod.modules.impl.render.Chams;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.EnderDragonEntityRenderer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EndCrystalEntityModel;
import net.minecraft.client.render.entity.state.EndCrystalEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EndCrystalEntityRenderer.class)
public abstract class MixinEndCrystalEntityRenderer extends EntityRenderer<EndCrystalEntity, EndCrystalEntityRenderState> {
    protected MixinEndCrystalEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Shadow
    @Final
    private static Identifier TEXTURE;

    @Unique
    private static final Identifier BLANK = Identifier.ofVanilla("textures/blank.png");

    @Unique
    private static final RenderLayer END_CRYSTAL_BLANK = RenderLayers.entityCutoutNoCull(BLANK);
    @Unique
    private static final RenderLayer END_CRYSTAL_CUSTOM = RenderLayers.entityCutoutNoCull(TEXTURE);

    @Unique
    private static final float SINE_45_DEGREES = MathHelper.sin(0.7853982F);
    @Unique
    private static final float PI3 = (float) Math.PI / 3F;

    @Unique
    private static final ModelPart OUTER_PART;
    @Unique
    private static final ModelPart INNER_PART;
    @Unique
    private static final ModelPart CORE_PART;

    static {
        ModelData outerData = new ModelData();
        outerData.getRoot().addChild("outer", ModelPartBuilder.create().uv(0, 0).cuboid(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), ModelTransform.NONE);
        OUTER_PART = TexturedModelData.of(outerData,64,32).createModel();

        ModelData innerData = new ModelData();
        innerData.getRoot().addChild("inner", ModelPartBuilder.create().uv(0, 0).cuboid(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), ModelTransform.NONE.withScale(0.875F));
        INNER_PART = TexturedModelData.of(innerData,64,32).createModel();

        ModelData coreData = new ModelData();
        coreData.getRoot().addChild("core", ModelPartBuilder.create().uv(32, 0).cuboid(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), ModelTransform.NONE.withScale(0.765625F));
        CORE_PART = TexturedModelData.of(coreData,64,32).createModel();
    }

    @Unique
    private float yOffset(float age, Chams module) {
        float f = age * module.floatValue.getValueFloat();
        float g = MathHelper.sin(f * 0.2F) / 2.0F + 0.5F;
        g = (g * g + g) * 0.4F * module.bounceHeight.getValueFloat();
        return g - 1.4F + module.floatOffset.getValueFloat();
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/EndCrystalEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    public void render(EndCrystalEntityRenderState state, MatrixStack matrixStack, OrderedRenderCommandQueue queue, CameraRenderState cameraRenderState, CallbackInfo ci) {
        Chams module = Chams.INSTANCE;
        if (module.customCrystal()) {
            ci.cancel();
            float age = module.spinSync.getValue() ? module.age : state.age;
            float h = yOffset(age, module);
            float j = age * 3.0F * module.spinValue.getValueFloat();

            matrixStack.push();
            // ===== 全局基础变换（三层共用：整体缩放、基础平移，不包含旋转！！）=====
            matrixStack.scale(2.0F * module.scale.getValueFloat(), 2.0F * module.scale.getValueFloat(), 2.0F * module.scale.getValueFloat());
            matrixStack.translate(0.0F, -0.5F, 0.0F);
            matrixStack.translate(0.0F, 1.5F + h / 2.0F, 0.0F);

            // 预计算基础四元数
            Quaternionf diagonalQuat = new Quaternionf().setAngleAxis(PI3, SINE_45_DEGREES, 0.0F, SINE_45_DEGREES);
            Quaternionf yRotQuat = RotationAxis.POSITIVE_Y.rotationDegrees(j);
            // outer：Y旋转 → 斜角
            Quaternionf outerQuat = yRotQuat.mul(diagonalQuat);
            // inner & core：斜角 → Y旋转
            Quaternionf innerCoreQuat = diagonalQuat.mul(yRotQuat);

            if (module.custom.getValue()) {
                if (module.outerFrame.booleanValue) {
                    matrixStack.push();
                    matrixStack.multiply(outerQuat);
                    ModelPlayer.render(matrixStack, OUTER_PART, module.fill, module.line, 1, module.chamsTexture.getValue());
                    matrixStack.pop();
                }
                if (module.innerFrame.booleanValue) {
                    matrixStack.push();
                    matrixStack.multiply(innerCoreQuat);
                    ModelPlayer.render(matrixStack, INNER_PART, module.fill, module.line, 1, module.chamsTexture.getValue());
                    matrixStack.pop();
                }
                if (module.core.booleanValue) {
                    matrixStack.push();
                    matrixStack.multiply(innerCoreQuat);
                    ModelPlayer.render(matrixStack, CORE_PART, module.fill, module.line, 1, module.chamsTexture.getValue());
                    matrixStack.pop();
                }
            }

            RenderLayer layer = module.texture.getValue() ? END_CRYSTAL_CUSTOM : END_CRYSTAL_BLANK;
            int k = OverlayTexture.DEFAULT_UV;
            if (state.baseVisible) {
                matrixStack.push();
                queue.submitModelPart(model.base, matrixStack, layer, state.light, k, null);
                matrixStack.pop();
            }

            // OuterFrame
            if (module.outerFrame.booleanValue) {
                matrixStack.push();
                matrixStack.multiply(outerQuat);
                int c = module.outerFrame.getValue().getRGB();
                queue.submitModelPart(OUTER_PART, matrixStack, layer, state.light, k, null, c, null);
                matrixStack.pop();
            }
            // InnerFrame
            if (module.innerFrame.booleanValue) {
                matrixStack.push();
                matrixStack.multiply(innerCoreQuat);
                int c = module.innerFrame.getValue().getRGB();
                queue.submitModelPart(INNER_PART, matrixStack, layer, state.light, k, null, c, null);
                matrixStack.pop();
            }
            // Core
            if (module.core.booleanValue) {
                matrixStack.push();
                matrixStack.multiply(innerCoreQuat);
                int c = module.core.getValue().getRGB();
                queue.submitModelPart(CORE_PART, matrixStack, layer, state.light, k, null, c, null);
                matrixStack.pop();
            }
            matrixStack.pop();

            Vec3d beamOffset = state.beamOffset;
            if (beamOffset != null) {
                matrixStack.push();
                float bx = (float) -beamOffset.x;
                float by = (float) (-beamOffset.y + h);
                float bz = (float) -beamOffset.z;
                matrixStack.translate(beamOffset);
                EnderDragonEntityRenderer.renderCrystalBeam(bx, by, bz, age, matrixStack, queue, state.light);
                matrixStack.pop();
            }
            super.render(state, matrixStack, queue, cameraRenderState);
        }
    }

    @Shadow
    @Final
    private EndCrystalEntityModel model;
}

package dev.luminous.asm.mixins;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import dev.luminous.Alien;
import dev.luminous.api.events.impl.Render2DEvent;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class MixinWorldRenderer {
    @Inject(method = "render", at = @At("TAIL"))
    public void render3dHook(
            ObjectAllocator allocator,
            RenderTickCounter tickCounter,
            boolean renderBlockOutline,
            Camera camera,
            Matrix4f positionMatrix,
            Matrix4f basicProjectionMatrix,
            Matrix4f projectionMatrix,
            GpuBufferSlice fogBuffer,
            Vector4f fogColor,
            boolean renderSky,
            CallbackInfo ci) {
        if (Alien.MODULE == null) {
            return;
        }
        MatrixStack matrices = new MatrixStack();
        // 1.21.11 supplies the active view matrix here; using only camera translation
        // leaves world-space overlays in screen-space and makes them appear invisible.
        matrices.multiplyPositionMatrix(positionMatrix);
        Alien.MODULE.render3D(matrices);
    }
}

package dev.luminous.asm.mixins.sodium;

import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockRenderer.class)
public class SodiumBlockRendererMixin {
}

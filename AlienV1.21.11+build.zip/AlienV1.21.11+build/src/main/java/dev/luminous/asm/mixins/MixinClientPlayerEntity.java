package dev.luminous.asm.mixins;

import com.mojang.authlib.GameProfile;
import dev.luminous.Alien;
import dev.luminous.api.events.Event;
import dev.luminous.api.events.impl.*;
import dev.luminous.asm.accessors.IClientPlayerEntity;
import dev.luminous.core.impl.CommandManager;
import dev.luminous.core.impl.RotationManager;
import dev.luminous.mod.modules.impl.client.AntiCheat;
import dev.luminous.mod.modules.impl.client.ClientSetting;
import dev.luminous.mod.modules.impl.exploit.PacketControl;
import dev.luminous.mod.modules.impl.movement.NoSlow;
import dev.luminous.mod.modules.impl.movement.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class MixinClientPlayerEntity extends AbstractClientPlayerEntity {

    @Shadow
    public Input input;
    @Final
    @Shadow
    protected MinecraftClient client;

    @Unique
    private boolean overridePacketRotation;
    @Unique
    private float packetYaw;
    @Unique
    private float packetPitch;

    private double lastBaseY;

    public MixinClientPlayerEntity(ClientWorld world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method = "pushOutOfBlocks",
            at = @At("HEAD"),
            cancellable = true)
    private void onPushOutOfBlocksHook(double x, double d, CallbackInfo info) {
        if (Velocity.INSTANCE.isOn() && Velocity.INSTANCE.blockPush.getValue()) {
            info.cancel();
        }
    }

    @Redirect(
            method = "applyMovementSpeedFactors",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"),
            require = 0
    )
    private boolean tickMovementHook(ClientPlayerEntity player) {
        if (NoSlow.INSTANCE.noSlow()) {
            return false;
        }
        return player.isUsingItem();
    }



    @Inject(at = {@At("HEAD")}, method = {"tickNausea"}, cancellable = true)
    private void updateNausea(CallbackInfo ci) {
        if (ClientSetting.INSTANCE.portalGui()) {
            ci.cancel();
        }
    }

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"), cancellable = true)
    public void onMoveHook(MovementType movementType, Vec3d movement, CallbackInfo ci) {
        MoveEvent event = MoveEvent.get(movement.x, movement.y, movement.z);
        Alien.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            ci.cancel();
        } else if (event.modify) {
            ci.cancel();
            super.move(movementType, new Vec3d(event.getX(), event.getY(), event.getZ()));
            Alien.EVENT_BUS.post(MovedEvent.INSTANCE);
        }
    }

    @Inject(method = "move", at = @At(value = "TAIL"))
    public void onMoveReturnHook(MovementType movementType, Vec3d movement, CallbackInfo ci) {
        Alien.EVENT_BUS.post(MovedEvent.INSTANCE);
    }

    @Shadow
    public abstract float getPitch(float tickDelta);

    @Shadow
    public abstract float getYaw(float tickDelta);

    @Inject(method = "tick",
            at = @At(value = "HEAD"))
    private void tickHead(CallbackInfo ci) {
        try {
            Alien.EVENT_BUS.post(TickEvent.get(Event.Stage.Pre));
        } catch (Exception e) {
            e.printStackTrace();
            if (ClientSetting.INSTANCE.debug.getValue())
                CommandManager.sendMessage("§4An error has occurred (ClientPlayerEntity.tick() [HEAD]) Message: [" + e.getMessage() + "]");
        }
    }

    @Inject(method = "tick",
            at = @At(value = "RETURN"))
    private void tickReturn(CallbackInfo ci) {
        try {
            Alien.EVENT_BUS.post(TickEvent.get(Event.Stage.Post));
        } catch (Exception e) {
            e.printStackTrace();
            if (ClientSetting.INSTANCE.debug.getValue())
                CommandManager.sendMessage("§4An error has occurred (ClientPlayerEntity.tick() [RETURN]) Message: [" + e.getMessage() + "]");
        }
    }

    @Shadow
    private int ticksSinceLastPositionPacketSent;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void onSendMovementPacketsHead(CallbackInfo info) {
        SendMovementPacketsEvent event = SendMovementPacketsEvent.get(getYaw(0), getPitch(0));
        Alien.EVENT_BUS.post(event);
        Alien.ROTATION.rotationYaw = event.getYaw();
        Alien.ROTATION.rotationPitch = event.getPitch();

        if (event.isModified()) {
            overridePacketRotation = true;
            packetYaw = event.getYaw();
            packetPitch = event.getPitch();
        } else {
            overridePacketRotation = false;
        }

        if (PacketControl.INSTANCE.isOn() && PacketControl.INSTANCE.positionSync.getValue()) {
            if (this.ticksSinceLastPositionPacketSent >= PacketControl.INSTANCE.positionDelay.getValueInt() - 1) {
                ((IClientPlayerEntity) this).setTicksSinceLastPositionPacketSent(50);
            }
        }
        if (RotationManager.snapBack) {
            ((IClientPlayerEntity) this).setTicksSinceLastPositionPacketSent(50);
            ((IClientPlayerEntity) this).setLastYaw(999);
            RotationManager.snapBack = false;
            return;
        }
        if (AntiCheat.INSTANCE.fullPackets.getValue()) {
            double d = this.getX() - this.lastX;
            double e = this.getY() - this.lastBaseY;
            double f = this.getZ() - this.lastZ;
            double g = this.getYaw() - this.lastYaw;
            double h = this.getPitch() - this.lastPitch;
            boolean bl3 = g != 0.0 || h != 0.0;
            if (AntiCheat.INSTANCE.force.getValue() || !(MathHelper.squaredMagnitude(d, e, f) > MathHelper.square(2.0E-4)) && this.ticksSinceLastPositionPacketSent >= 19 || bl3) {
                ((IClientPlayerEntity) this).setTicksSinceLastPositionPacketSent(50);
                ((IClientPlayerEntity) this).setLastYaw(999);
            }
        }
    }

    @Redirect(method = "sendMovementPackets", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"))
    private float redirectSendPacketYaw(ClientPlayerEntity instance) {
        if (overridePacketRotation) {
            return packetYaw;
        }
        return instance.getYaw();
    }

    @Redirect(method = "sendMovementPackets", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"))
    private float redirectSendPacketPitch(ClientPlayerEntity instance) {
        if (overridePacketRotation) {
            return packetPitch;
        }
        return instance.getPitch();
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void onSendMovementPacketsTailCleanup(CallbackInfo info) {
        overridePacketRotation = false;
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void tickMovement(CallbackInfo ci) {
        Alien.EVENT_BUS.post(TickMovementEvent.INSTANCE);
    }
}

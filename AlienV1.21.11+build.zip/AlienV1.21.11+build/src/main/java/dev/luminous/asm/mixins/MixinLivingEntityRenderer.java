package dev.luminous.asm.mixins;

import dev.luminous.api.utils.math.MathUtil;
import dev.luminous.core.impl.RotationManager;
import dev.luminous.mod.modules.impl.client.ClientSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class MixinLivingEntityRenderer<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> {

    @Unique
    private float cachedBodyYaw;
    @Unique
    private float cachedHeadYaw;
    @Unique
    private float cachedPitch;

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    public void modifyRenderStateRotation(T entity, S state, float partialTicks, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (entity != mc.player || !ClientSetting.INSTANCE.rotations.getValue()) {
            return;
        }

        float targetBodyYaw = RotationManager.getRenderYawOffset();
        float targetHeadYaw = RotationManager.getRotationYawHead();
        float targetPitch = RotationManager.getRenderPitch();

        float interpolatedBodyYaw = MathUtil.interpolateAngle(cachedBodyYaw, targetBodyYaw, partialTicks);
        float interpolatedHeadYaw = MathUtil.interpolateAngle(cachedHeadYaw, targetHeadYaw, partialTicks);
        float interpolatedPitch = MathUtil.interpolate(cachedPitch, targetPitch, partialTicks);

        state.bodyYaw = interpolatedBodyYaw;
        state.relativeHeadYaw = interpolatedHeadYaw - interpolatedBodyYaw;
        state.pitch = interpolatedPitch;

        cachedBodyYaw = targetBodyYaw;
        cachedHeadYaw = targetHeadYaw;
        cachedPitch = targetPitch;
    }
}

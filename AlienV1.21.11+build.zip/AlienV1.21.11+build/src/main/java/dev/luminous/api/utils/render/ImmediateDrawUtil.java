package dev.luminous.api.utils.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.ProjectionMatrix2;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.Window;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * 1.21.11 立即模式渲染工具：负责把 {@link BufferBuilder} 的内容提交到 GPU。
 * 顶点坐标由调用方在 CPU 侧变换好（相机旋转烘焙进顶点、坐标相机相对），世界绘制 modelView 用单位阵。
 */
public final class ImmediateDrawUtil {
	private static final ProjectionMatrix2 GUI_PROJECTION_MATRIX = new ProjectionMatrix2("alien_gui", 1000.0F, 11000.0F, true);

	// 正常深度管线
	private static final RenderPipeline POS_COLOR_QUADS = registerPosColor("quads", VertexFormat.DrawMode.QUADS);
	private static final RenderPipeline POS_COLOR_LINES = registerPosColor("lines", VertexFormat.DrawMode.LINES);
	private static final RenderPipeline POS_COLOR_DEBUG_LINES = registerPosColor("debug_lines", VertexFormat.DrawMode.DEBUG_LINES);
	private static final RenderPipeline POS_COLOR_DEBUG_LINE_STRIP = registerPosColor("debug_line_strip", VertexFormat.DrawMode.DEBUG_LINE_STRIP);
	private static final RenderPipeline POS_COLOR_TRIANGLE_FAN = registerPosColor("triangle_fan", VertexFormat.DrawMode.TRIANGLE_FAN);
	private static final RenderPipeline POS_COLOR_TRIANGLE_STRIP = registerPosColor("triangle_strip", VertexFormat.DrawMode.TRIANGLE_STRIP);
	private static final RenderPipeline LINES_WIDE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
					.withLocation(Identifier.of("alienclient", "pipeline/lines_wide"))
					.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
					.withDepthWrite(false)
					.build()
	);
	private static final RenderPipeline POS_TEX_COLOR_QUADS = registerPosTexColor("quads", VertexFormat.DrawMode.QUADS);
	private static final RenderPipeline POS_TEX_COLOR_DEBUG_LINES = registerPosTexColor("debug_lines", VertexFormat.DrawMode.DEBUG_LINES);

	private static final RenderPipeline POS_COLOR_QUADS_NO_DEPTH = registerPosColorNoDepth("quads", VertexFormat.DrawMode.QUADS);
	private static final RenderPipeline POS_COLOR_LINES_NO_DEPTH = registerPosColorNoDepth("lines", VertexFormat.DrawMode.LINES);
	private static final RenderPipeline POS_COLOR_DEBUG_LINES_NO_DEPTH = registerPosColorNoDepth("debug_lines", VertexFormat.DrawMode.DEBUG_LINES);
	private static final RenderPipeline POS_COLOR_DEBUG_LINE_STRIP_NO_DEPTH = registerPosColorNoDepth("debug_line_strip", VertexFormat.DrawMode.DEBUG_LINE_STRIP);
	private static final RenderPipeline POS_COLOR_TRIANGLE_FAN_NO_DEPTH = registerPosColorNoDepth("triangle_fan", VertexFormat.DrawMode.TRIANGLE_FAN);
	private static final RenderPipeline POS_COLOR_TRIANGLE_STRIP_NO_DEPTH = registerPosColorNoDepth("triangle_strip", VertexFormat.DrawMode.TRIANGLE_STRIP);
	private static final RenderPipeline LINES_WIDE_NO_DEPTH = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
					.withLocation(Identifier.of("alienclient", "pipeline/lines_wide_no_depth"))
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withDepthWrite(false)
					.build()
	);

	private ImmediateDrawUtil() {
	}

	private static RenderPipeline registerPosColor(String name, VertexFormat.DrawMode drawMode) {
		return RenderPipelines.register(
				RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
						.withLocation(Identifier.of("alienclient", "pipeline/pos_color_" + name))
						.withCull(false)
						.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
						.withDepthWrite(false)
						.withVertexFormat(VertexFormats.POSITION_COLOR, drawMode)
						.build()
		);
	}

	private static RenderPipeline registerPosColorNoDepth(String name, VertexFormat.DrawMode drawMode) {
		return RenderPipelines.register(
				RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
						.withLocation(Identifier.of("alienclient", "pipeline/pos_color_no_depth_" + name))
						.withCull(false)
						.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
						.withDepthWrite(false)
						.withVertexFormat(VertexFormats.POSITION_COLOR, drawMode)
						.build()
		);
	}

	private static RenderPipeline registerPosTexColor(String name, VertexFormat.DrawMode drawMode) {
		return RenderPipelines.register(
				RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
						.withLocation(Identifier.of("alienclient", "pipeline/pos_tex_color_" + name))
						.withCull(false)
						.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
						.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, drawMode)
						.build()
		);
	}

	/** GUI 空间绘制：正交投影 + z=-11000 平移。调用后 builder 不可再用。 */
	public static void drawGui(BufferBuilder builder) {
		drawGui(builder, null);
	}

	/**
	 * 重载方法，消除Java重载歧义，参数名改为useDepthTest
	 */
	public static void drawGui(BufferBuilder builder, boolean useDepthTest) {
		if (useDepthTest) {
			drawGui(builder);
		} else {
			drawGuiNoDepth(builder);
		}
	}

	/** GUI 空间绘制并绑定纹理（管线需含 Sampler0）。调用后 builder 不可再用。 */
	public static void drawGuiTextured(BufferBuilder builder, GpuTextureView textureView) {
		drawGui(builder, textureView);
	}

	/** 世界空间绘制：顶点已由调用方烘焙相机旋转并减去相机坐标，modelView 用单位阵。调用后 builder 不可再用。 */
	public static void drawWorld(BufferBuilder builder) {
		drawWorld(builder, null, false);
	}

	public static void drawWorld(BufferBuilder builder, boolean noDepth) {
		drawWorld(builder, null, noDepth);
	}

	/** 世界空间绘制并绑定纹理（管线需含 Sampler0）。调用后 builder 不可再用。 */
	public static void drawWorldTextured(BufferBuilder builder, GpuTextureView textureView) {
		drawWorld(builder, textureView, false);
	}

	public static void drawWorld(BufferBuilder builder, GpuTextureView textureView, boolean noDepth) {
		draw(builder, new Matrix4f(), textureView, noDepth);
	}

	/** GUI正交绘制，使用无深度测试管线，永远置顶，不会被深度遮挡 */
	public static void drawGuiNoDepth(BufferBuilder builder) {
		MinecraftClient client = MinecraftClient.getInstance();
		Window window = client.getWindow();
		RenderSystem.backupProjectionMatrix();
		try {
			RenderSystem.setProjectionMatrix(
					GUI_PROJECTION_MATRIX.set((float) window.getFramebufferWidth() / window.getScaleFactor(), (float) window.getFramebufferHeight() / window.getScaleFactor()),
					ProjectionType.ORTHOGRAPHIC
			);
			draw(builder, new Matrix4f().setTranslation(0.0F, 0.0F, -11000.0F), null, true);
		} finally {
			RenderSystem.restoreProjectionMatrix();
		}
	}

	private static void drawGui(BufferBuilder builder, GpuTextureView textureView) {
		MinecraftClient client = MinecraftClient.getInstance();
		Window window = client.getWindow();
		RenderSystem.backupProjectionMatrix();
		try {
			RenderSystem.setProjectionMatrix(
					GUI_PROJECTION_MATRIX.set((float) window.getFramebufferWidth() / window.getScaleFactor(), (float) window.getFramebufferHeight() / window.getScaleFactor()),
					ProjectionType.ORTHOGRAPHIC
			);
			draw(builder, new Matrix4f().setTranslation(0.0F, 0.0F, -11000.0F), textureView, false);
		} finally {
			RenderSystem.restoreProjectionMatrix();
		}
	}

	private static void draw(BufferBuilder builder, Matrix4f modelView, GpuTextureView textureView, boolean noDepth) {
		try (BuiltBuffer builtBuffer = builder.end()) {
			BuiltBuffer.DrawParameters parameters = builtBuffer.getDrawParameters();
			RenderPipeline pipeline = pipelineFor(parameters.mode(), parameters.format(), noDepth);
			Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
			RenderSystem.ShapeIndexBuffer shapeIndexBuffer = RenderSystem.getSequentialBuffer(parameters.mode());
			GpuBuffer indexBuffer = shapeIndexBuffer.getIndexBuffer(parameters.indexCount());
			VertexFormat.IndexType indexType = shapeIndexBuffer.getIndexType();
			GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
					.write(modelView, new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), new Vector3f(), new Matrix4f());
			GpuBuffer vertexBuffer = pipeline.getVertexFormat().uploadImmediateVertexBuffer(builtBuffer.getBuffer());
			GpuTextureView colorView = RenderSystem.outputColorTextureOverride != null
					? RenderSystem.outputColorTextureOverride
					: framebuffer.getColorAttachmentView();

			GpuTextureView depthView;
			if (noDepth) {
				depthView = null;
			} else {
				depthView = framebuffer.useDepthAttachment
						? (RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : framebuffer.getDepthAttachmentView())
						: null;
			}

			try (RenderPass renderPass = RenderSystem.getDevice()
					.createCommandEncoder()
					.createRenderPass(() -> "alien_immediate", colorView, OptionalInt.empty(), depthView, OptionalDouble.empty())) {
				RenderSystem.bindDefaultUniforms(renderPass);
				renderPass.setUniform("DynamicTransforms", dynamicTransforms);
				renderPass.setPipeline(pipeline);
				if (textureView != null) {
					renderPass.bindTexture("Sampler0", textureView, RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
				}
				renderPass.setVertexBuffer(0, vertexBuffer);
				renderPass.setIndexBuffer(indexBuffer, indexType);
				renderPass.drawIndexed(0, 0, parameters.indexCount(), 1);
			}
		}
	}

	private static RenderPipeline pipelineFor(VertexFormat.DrawMode drawMode, VertexFormat format, boolean noDepth) {
		if (noDepth) {
			if (format == VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH) {
				return LINES_WIDE_NO_DEPTH;
			}
			return switch (drawMode) {
				case QUADS -> POS_COLOR_QUADS_NO_DEPTH;
				case LINES -> POS_COLOR_LINES_NO_DEPTH;
				case DEBUG_LINES -> POS_COLOR_DEBUG_LINES_NO_DEPTH;
				case DEBUG_LINE_STRIP -> POS_COLOR_DEBUG_LINE_STRIP_NO_DEPTH;
				case TRIANGLE_FAN -> POS_COLOR_TRIANGLE_FAN_NO_DEPTH;
				case TRIANGLE_STRIP -> POS_COLOR_TRIANGLE_STRIP_NO_DEPTH;
				default -> throw new IllegalArgumentException("Unsupported no-depth draw mode: " + drawMode);
			};
		}

		if (format == VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH) {
			return LINES_WIDE;
		}
		if (format == VertexFormats.POSITION_TEXTURE_COLOR) {
			return switch (drawMode) {
				case QUADS -> POS_TEX_COLOR_QUADS;
				case DEBUG_LINES -> POS_TEX_COLOR_DEBUG_LINES;
				default -> throw new IllegalArgumentException("Unsupported textured draw mode: " + drawMode);
			};
		}
		return switch (drawMode) {
			case QUADS -> POS_COLOR_QUADS;
			case LINES -> POS_COLOR_LINES;
			case DEBUG_LINES -> POS_COLOR_DEBUG_LINES;
			case DEBUG_LINE_STRIP -> POS_COLOR_DEBUG_LINE_STRIP;
			case TRIANGLE_FAN -> POS_COLOR_TRIANGLE_FAN;
			case TRIANGLE_STRIP -> POS_COLOR_TRIANGLE_STRIP;
			default -> throw new IllegalArgumentException("Unsupported draw mode: " + drawMode);
		};
	}
}
